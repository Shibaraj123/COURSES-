#Problem.8

def f(x):                                          #function is defined according to the question
	y= x**(95/100)
	return y


n=0
x=10
while x>=2:                       # while-loop is used to find no. of iterations we get until x<2
	x = f(x)
	n += 1
	
print("The number of iterations the function performs to get x<2 is ",n)                                                
