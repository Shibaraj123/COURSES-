#Problem.7

from math import *                                       #imported all objects from math module

def f(t):
	y= sin(2*t*pi/180)                 #function gives output of sin(2t) where t is in degrees
	return y
	
θ = [0,10,20,30,40,50,60,70,80,90]                      #defined a list x to get the needed output
for i in θ :                                            #used for loop to get the output
	print(i,f(i))
