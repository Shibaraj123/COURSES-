#Problem.4

def f(x) :                #the function is defined according to thr question
	q= x//2
	r= x%2
	return q, r
	


s= int(input("value of s="))             #input variable s is set
a,b = f(s)                               # variable a,b are assigned to store q,r
print("quotient=",a,"remainder=",b)
