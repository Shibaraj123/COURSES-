#Problem.5


def f(x,y) :                #the function is defined according to thr question

	q= (x+2)//(y+2)
	r= (x+2)%(y+2)
	return q, r
	
	
x= int(input("value of x= "))    #the input variable x and y are defined
y= int(input("value of y= "))
a,b= f(x,y)

print("quotient= ",a,"remainder=",b)                  # output is printed
