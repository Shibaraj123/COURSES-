#Problem.6
def f(x,y,z):                            #function defined such that sticks forms  triangle
	if (x+y>z) and (y+z>x) and (x+z>y):
		return True
	else:
		return False
	
a= int(input("length of first stick= "))     #a,b,c are input variables for stick length
b= int(input("length of second stick= "))
c= int(input("length of third stick= "))

if f(a,b,c) is True:          #iff a,b,c satisfy the defined function,the sticks form a triangle 
	print("True")
else:
	print("False")

