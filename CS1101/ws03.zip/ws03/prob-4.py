x= [0,3,1,2,8,7,9,0,4,7]

y = x[0]

for i in x:
    if i>y :
    	y=i

print(y , "is the largest number in the list")
    
