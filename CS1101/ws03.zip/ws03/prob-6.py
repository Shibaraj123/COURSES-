x = [0, 3, 1, 2, 8, 7, 9, 0, 4, 7]
for i in x:
  for j in range(i+1, len(x)):
     if x[i]> x[j] :
       temp = x[i]
       x[i] = x[j]
       x[j] = temp
       
print("the list in ascending order is",x )          
