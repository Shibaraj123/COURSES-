x= [0,3,1,2,8,7,9,0,4,7]
#5.a
largest= x[0]
for i in x:
  if i> largest :
    largest = i
print(largest,"is largest","having position as", x.index(largest))
#5.b
smallest= x[0]
for i in x:
  if i< smallest:
    smallest= i
print(smallest, "is smallest","having position of",x.index(smallest))
