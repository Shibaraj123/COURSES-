x= [-1, -3, 7, 9,-4, 3, 8, 9, -2]
for i in x:
  for j in range(i+1, len(x)):
     if x[i]> x[j] :
       temp = x[i]
       x[i] = x[j]
       x[j] = temp
       
print("the list in ascending order is",x )          
