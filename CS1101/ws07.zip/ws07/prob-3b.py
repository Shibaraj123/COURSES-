#Problem-3.b
# Function to check if string contains at least one vowel
def fn(name):
	vowels= "AEIOUaeiou"
	for char in name:
		if char in vowels:
	            return True
	return False
			
#Get 5 names and appends name in list n 	
n= []
for i in range(5):
	name= input("Enter 5 names with at least one vowel=")
	if fn(name):
		n.append(name)
	
# Writes the 5 names in a file 	
with open('names(b).txt','w') as f:
	for name in n:
		f.write(name+'\n')
		
	
