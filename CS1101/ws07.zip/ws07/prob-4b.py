#Problem.4b
#read the file and made separate lists for roll and marks
with open('roll-marks.txt', 'r') as f:
	roll= []
	marks= []
	for i in f:
		a= i.split()
		roll.append(a[0])
		marks.append(int(a[1]))
		
#if marks is less than 50 , grace marks of 5 will add	
	for i in range(1,len(marks)):
		if marks[i]<50:
			marks[i] += 5
			
#write the new marks in file f1		
with open('new-marks.txt', 'w') as f1:
	for i in range(50):
		f1.write(str(roll[i]) + " "+ str(marks[i])+'\n')
