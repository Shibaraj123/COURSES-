#Problem-3.a
with open('names(a).txt','w') as f:
	for i in range(5):
		i= str(input("Enter a name : "))
		f.write(i+ "\n")
	
	
	
	
