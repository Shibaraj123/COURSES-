#Problem.4a
#read the file and made separate lists for roll and marks
with open('roll-marks.txt', 'r') as f:
	roll= []
	marks= []
	for i in f:
		a= i.split()
		roll.append(a[0])
		marks.append(int(a[1]))
#write highest marks in another file f1 	
h= 0
with open('high-marks.txt', 'w') as f1:
	h= 0
	for i in range(50):
		if marks[i]>marks[h] :
			h= i
			
	f1.write(str(marks[h]))
