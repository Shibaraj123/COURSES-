#Problem.1

n= int(input("Type an integer="))
with open('fibonacci.txt','w') as f:
	x=1
	y=1
	f.write("1")
	for i in range(n):
		x,y=y,x+y
		f.write("\n")
		a= str(x)
		f.write(a)		
		
	
