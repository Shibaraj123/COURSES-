#Problem.2
n= int(input("TYPE A INTEGER= "))
with open('factorial.txt','w') as f:
# defining function for factorial
	def fn(n):
	  if (n==1 or n==0):
	      return 1
	  else:
	    y= n*fn(n-1)
	    return y
	for i in range(1,n+1):
		f.write(str(i)+' '+str(fn(i))+"\n")
		
