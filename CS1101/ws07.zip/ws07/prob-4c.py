#Problem.4c
#read the file and made separate lists for roll and marks
with open('new-marks.txt', 'r') as f:
	roll= []
	marks= []
	for i in f:
		a= i.split()
		roll.append(a[0])
		marks.append(a[len(a)-1])

#Write roll numbers who failed in f1 file
with open('failed.txt', 'w') as f1:
	for i in range(len(marks)):
		if int(marks[i])<50:
			failed = roll[i]
			f1.write(str(failed)+"\n")
		
