#Problem.5
#Open the file to read
with open('roll-marks.txt','r') as f:
	roll= []
	marks= []
	for i in f:
		a= i.split()
		roll.append(a[0])
		marks.append(int(a[1]))

#Sorting in descending order		
for i in range(0,len(marks)):
	for j in range(i,len(marks)):
		if marks[i] < marks[j]:
			marks[i],marks[j]= marks[j],marks[i]

#Write the marks in sorted order in f1 file		
with open('sorted-marks.txt', 'w') as f1 :
	for i in range(50):
		f1.write(str(marks[i])+ '\n')
				
