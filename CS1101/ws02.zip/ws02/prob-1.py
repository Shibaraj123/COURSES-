#1.a
x= "The quick brown fox jumps over the lazy dog"
#1.b
if 'fox'in x :
  print("found fox in x")
else:
  print("not found fox in x")
#1.c
print(x[::-1])
#1.d
print(x[2::3])
