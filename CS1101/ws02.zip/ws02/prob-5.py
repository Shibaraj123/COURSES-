#5
a=2 #initial value
r=3 #common ratio
for i in range(10):
  y= a*(r**i)
  print(i+1," ",y)
  
