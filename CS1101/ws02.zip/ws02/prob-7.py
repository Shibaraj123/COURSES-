#7.a
for n in range(1,6):
  for m in range(1,6):
   c= round(((n-m)**2)/((n+m)**2),2)
   print(n, m , c)
print("the final sum is", c)

#7.b
for n in range(1,6):
  for m in range(n+1,6):
   c= round(((n-m)**2)/((n+m)**2),2)
   print(n, m , c)
print("the final sum is", c)
