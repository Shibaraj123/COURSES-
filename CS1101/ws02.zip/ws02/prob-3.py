#3.a
fname="Shibaraj"
lname= "Sahu"
roll= 132
#3.b
print(fname[0]+lname[0])
#3.c
print(fname[0]+lname[0]+"23MS"+ "132")
