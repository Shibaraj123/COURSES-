#4
x= "abcdefghijkl"
for i in range(12):
 print(x[0:12-i])
