#6.Fibonacci Series

a=0
b=1
print(1,"  ",b)
for i in range(2,31):
  c=a+b
  a=b
  b=c
  print(i, "  ",c)
