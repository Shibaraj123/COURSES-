#2.a
for i in range(1,15):
   print(i, ' ', i*i)
#2.b
x= 3.1415
y= 22
z= 7
print(type(x/y))
print(type(y/z))
print(type(z/x))

print('%3.2f'%x,'%7.6f'%(y/z))

n=15
for i in range(1,n):
  x=i
  y=i*i
  print('%4d'%x, '%5d'%y)
