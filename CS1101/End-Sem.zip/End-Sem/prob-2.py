#Problem-2

#Input is taken from user and stored as x and y 
x = int(input("Type a number : "))
y = int(input("Type another number : "))

# For y always being the greater number
if y > x :
	x,y = y,x

#Defining a function to get gcd of a and y :
def f(x, y):
    gcd = int()
    for c in range(y,-1,-1):      
          #Range of the c is taken in reverse to check till the gcd is reached 
        if x % c == 0 and y % c == 0:
            gcd = c
            break

    return gcd
    
#Output gives gcd(x,y)
print("The greatest common divisor of ",x ,"and",y, "is",f(x,y))
