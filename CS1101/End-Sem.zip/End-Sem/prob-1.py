#Problem-1


#The given values of a3 and a7
a3 = 1.22
a7 = 1.86

#Finding a,r
r = round(((a7 - a3)/ 4),3)

a = a3 - 3*r 

print("The value of common difference r is ",r)
print("The value of a is ",a)

#Defining a function for AP series
def f(n) :
	y = a + n*r
	return y

#Summation of series for 99 terms	
S = 0.0
for i in range(100):
	S += f(i)

print(S)	
	
	

