#6

a=1
b=0
n = int(input("total number of terms in fibonacci to be taken  "))

for i in range(1,n+1):
    c= a+b
    a,b=b,c
    print(c)
