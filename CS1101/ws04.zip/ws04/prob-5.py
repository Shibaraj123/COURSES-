p = int(input("give a number n= "))
q=2
a=0
while q<p :
	if p%q == 0:
		a=1
	q = q + 1

if a == 0:
	print(p,"is prime number") 
else:
	print(p,"is NOT prime number") 
