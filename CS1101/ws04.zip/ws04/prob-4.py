a = int(input("give an integer a="))

k=0
i=0
while 2**k < a :
    i = 2**k
    k += 1
print(k-1)
# k is largest positive integer for which 2**k<20 
