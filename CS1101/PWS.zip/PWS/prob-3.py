#Problem-3

from math import *
#Defining a function 
def f(x):
    y=0.0
    w= 0.1
    y=sin(2*w*pi*x)
    return y
   
#Choosing w= 1/10 to get 4 cycles of sin function
x=-20.0
x_values,f_values=[],[]
for i in range(1,201):
     print(x,f(x))
     x+= 0.2
     x_values.append(x)
     f_values.append(f(x))
# Writing the x,f values in a file
with open('Output3.dat','w') as f:
        for j in range(200):
             f.write(str(x_values[j])+' '+str(f_values[j])+'\n') 
