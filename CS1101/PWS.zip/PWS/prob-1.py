#Problem-1
names = []
grades = []
#Opening and reading the file
with open('Grades1.dat',"r") as f :
	for line in f:
		a = line.split()
		names.append(a[0])
		grades.append(int(a[1]))

#Sorting Grades in descending order
for i in range(len(grades)):
	for j in range(i,len(grades)):
		if grades[i] < grades[j]:
			grades[i],grades[j]= grades[j],grades[i]
			names[i],names[j]= names[j],names[i]
			
			
#Opening and writing the sorted grades in new file	
with open('Sorted-Grades.dat', 'w') as f1 :
	for i in range(len(names)):
		f1.write(str(grades[i])+'  '+names[i]+ '\n')

	
