from math import *
with open('data4.dat', 'w') as f :
	a,b=1,1
	rfib = 1.0
	i = 0
	while abs(rfib-3.3598856)>=0.000001:
		f.write(str(i+1)+" "+str(rfib)+ "\n")
		a,b=b,a+b
		rfib+=1/a   
		i+=1

print('The number iterations to reach 6th place is :', i+1)
