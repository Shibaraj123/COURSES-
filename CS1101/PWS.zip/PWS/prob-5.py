Name=[]
Marks=[]
name_mark={}
with open('Grades2.dat') as f:
    for line in f.readlines():
        name,mark=line.split('\t')
        Name.append(name)
        Marks.append(int(mark))
        name_mark[name]=int(mark)
        
        
        
def sort_students(name_mark):
        students=list(name_mark.items())
        students_sorted=sorted(students, key=lambda student:(-student[1],student[0]))
        
        return students_sorted
        
sorted_students=sort_students(name_mark)

with open('Output5.dat','w') as f:
        for key,value in sorted_students:
                f.write(str(value)+'\t'+ key + '\n')
