#Problem-2
import math
𝞼 = float()
# Defining the function as given
def f(x):
	y = math.exp(-x**2/𝞼)
	return y
	
#Storing the function values in a list
f_values= []
x_values= []
𝞼 = 4
x= float()

# 100 value points with 0.1 difference are chosen
for i in range(100) :
	x = -5 + i/10
	f_values.append(f(x))
	x_values.append(round(x,3))
#Finding maximum value of the function
y= list(f_values)
h = 0	
for i in range(100):
	y[i]= float(y[i])
	if y[i] > y[h]:
	  	h = i
print("The maximum value of the function in [-5,5] is " ,y[h])



# finding values of x* for which the function is  1/2  of max f_value
x = -5
a = (1/2)*y[h]
marked_values = []
marked_f = []
for i in range(len(y)):
	x+=0.1
	if abs(f(x)-a)<= 0.09:
		print("The values of x* for which f(x*)= 1/2 * f_max", x)
		marked_values.append(x)
		marked_f.append(f(x))
	else:
	     pass
	     
with open('output-Prob2.dat', 'w') as f:
	for i in range(100):
		f.write(str(x_values[i])+ "  " + str(f_values[i])+'\n')
			
with open('Output(marked-value).dat','w') as f1:
        for i in range(8):
             f1.write(str(marked_values[i])+' '+str(marked_f[i])+'\n')





