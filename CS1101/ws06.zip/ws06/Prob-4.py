from math import *
                                           #taking 100 data points for sinx in [0,2pi]

x=0
for i in range(101):
     x=0+(i*pi/50)
     y=sin(x)
     print(x,y)
