from math import *

def f(x):                  #defining function to calculate pi using series in prob-1
    a=0.0
    sign=1
    k=0
    
    while abs(pi-a)>=0.05:
       print(k,a,pi)
       a+=4*(sign/(2*k+1))
       sign=-sign*(x**(2*k+1))
       k=k+1
        
    return k,a,pi
    
x=1                     #printing iteration no., calculated value,actual value of pi
a,b,c=f(1)
print(a,b,c)

