#Problem.2
from math import *

def f(x,n):                                    #defining the function for the series
    a=0.0
    sign=1
    for i in range(1,n+1):
        a+=sign*((x)**i)/i
        sign=-sign
    
    return a
    
x= -0.25                                    #to compute log(0.75) using above function 
p=1   
while abs(log(0.75)-f(x,p))>10**(-4):
      p+=1
print('The number of terms required is',p)
print("the computed value of log(0.75) is", f(x,p))

#The program gives number of iteration required to calculate the log(0.75) value
