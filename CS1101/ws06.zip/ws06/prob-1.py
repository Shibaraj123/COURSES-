#Problem-5

from math import pi

def f(x,n):                            #defining function of arctan with appropriate variables 
    arctan = 0.0
    sign = 1
    for i in range(n+1):
        arctan += sign*(x**((2*i)+1)/((2*i)+1))
        sign = -sign
          
    return'The summation of the arctan series',arctan
     
x=1
n=int(input('number of term= '))
a,b = f(x, n)
print(a,b)


def g(x):             #defining a function to find abs diff of pi and computed value
    y = 0.0
    sign=1
    p=0
    
    while abs(pi-y)>= 0.01:
       y+=4*(sign/(2*p+1))
       sign=-sign*(x**(2*p+1))
       p=p+1
        
    return p,y,abs(pi-y)
    
x=1
a, b, c = g(1)
print("number of terms to calculate value of pi: ",a)
print("Exact Value of pi : ",pi)
print("Computed value of pi :",b)
print("the absolute difference:",c)

