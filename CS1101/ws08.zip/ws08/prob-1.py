#PROBLEM-1

a=int(input('Type a number= '))
b=int(input('Type another number= '))
#Defining a function to find primes
def prime(x):
	if x == 1:
		return False
	if x<=3 :
		return True
	if x%2 == 0 or x%3== 0:
		return False
	i=5
	while i*i <= x:
		if x%i==0 or x%(i+2)==0 :
			return False
		i +=6
	return True 

#Two cases to find primes between a and b

if b>a:
	for x in range(a,b):           # Case-1: when b is greater than a
		if prime(x):
		  print(x)
		  
if a>b:
	for x in range(b,a):           # case-2 : when b is smaller than a
		if prime(x):
		  print(x)
