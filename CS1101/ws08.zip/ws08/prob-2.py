#PROBLEM-2

import math
#defined a function for exponential series
def exp(n,x):
    a = 1.0
    store = a
    for i in range(1,n):
        a = (x/i)*a
        store = store + a
    return store
    
    
pi = math.pi   
x= pi                               #to compute exp(pi)  
p=1   
while abs(math.exp(pi)-exp(p,x))>10**(-4):
      p+=1
print('The number of terms required is',p)
print("The computed value of exp(pi) is ", exp(p,x))
print('The actual value is ' ,math.exp(pi))
print("The absolute difference is ",math.exp(pi)-exp(p,x))
    
