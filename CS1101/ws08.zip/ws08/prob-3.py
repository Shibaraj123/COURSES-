a = int(input('Side-1= '))
b = int(input('Side-2= '))
c = int(input('Side-3= '))

#A function to check a,b,c forms side of a triangle

def triangle(a,b,c):
    if (a+b) >= c and (b+c)>=a and (c+a)>=b:
        return True
    return False

#calling the function to check sides from user input
if (triangle(a,b,c)) :
	print(a ,',',b,',','and',c, "forms a triangle.")
else :
	print(a ,',',b,',','and',c, "DOES NOT form a triangle.")
