#Problem-2 
#Open the file to read
with open('data1.dat','r') as f:
	Name = []
	Marks= []
	for line in f :
		a= line.split()
		Name.append(a[0])
		Marks.append(float(a[1]))

average = sum(Marks)/8
print(a)
 
print('Average marks is',average)
 
for i in range(0,len(Marks)):
	for j in range(i,len(Marks)):
		if Marks[i] < Marks[j]:
			Marks[i],Marks[j]= Marks[j],Marks[i]
			Name[i], Name[j] = Name[j], Name[i]

G = []		
for i in range(len(Marks)):
	if Marks[i] >= 90:
		G.append('+A')
		
	elif Marks[i] >= 80:
		G.append("A")
	elif Marks[i] >= 70:
		G.append("+B")
	elif Marks[i] >= 60:
		G.append("B")
	elif Marks[i] >= 50:
		G.append("+C")
	elif Marks[i] >= 40:
		G.append("C")
	elif Marks[i] >= 30:
		G.append("D")
	else:
		G.append("F")
		
		
with open('sorted-marks.txt', 'w') as f1 :
	for i in range(1,9):
		f1.write(str(Marks[i])+" "+ Name[i]+ " "+ G[i]+'\n')

