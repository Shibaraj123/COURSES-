#PROBLEM-1

from math import exp
# Defined the given function 
def f(x):
	y = x*exp(-x/2.71)
	return y
#Separate Lists for x,f values 
f_values= []
x_values= []

#Evenly spread 1000 pts from given domain
for i in range(1000):
	x= 0 + i/125
	x_values.append(round(x,3))
	f_values.append(f(x))
	
# For finding the maximum value 
y= list(f_values)
z= list(x_values)
h = 0	
for i in range(1000):
	y[i]= float(y[i])
	if y[i] > y[h]:
	  	h = i
print("The maximum value of the function in [0,8] is " ,y[h] ,"at",z[h])
	
	
#Making two files to save output and maximum values
with open('output-Prob1.dat', 'w') as f:
	for i in range(1000):
		f.write(str(x_values[i])+ "  " + str(f_values[i])+'\n')
		
with open('max-prob1.dat','w') as f :
	f.write(str(z[h])+ '  ' + str(y[h]))
